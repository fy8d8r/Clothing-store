"""Современный интерфейс на customtkinter: вход, каталог, фильтры, добавление/удаление,
выбор цвета и тёмная тема."""
import os
import shutil
import traceback
from pathlib import Path
import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk

import customtkinter as ctk
from PIL import Image

from .db import SIZE_ORDER
from .theme import DEFAULT_COLOR, PRESET_COLORS, darken, palette

ALL = "Все"
FONT = "Segoe UI"  # если шрифта нет в системе, Tk подставит запасной


def money(value):
    text = f"{value:,.2f}".replace(",", " ")
    if text.endswith(".00"):
        text = text[:-3]
    return text + " ₽"


class App(ctk.CTk):
    def __init__(self, db):
        super().__init__()
        self.db = db
        self.title("Style Store — магазин одежды")
        self.geometry("1140x720")
        self.minsize(1020, 640)

        self.user = None
        self.accent, self.mode = DEFAULT_COLOR, "light"
        self.pal = palette(self.mode, self.accent)
        self.screen, self.tree, self.rows = "login", None, {}
        self.container, self._job = None, None
        self.cart = {}
        self._images = []

        # фильтры хранятся в App, чтобы не сбрасываться при смене темы
        self.search_var = tk.StringVar()
        self.cat_var = tk.StringVar(value=ALL)
        self.size_var = tk.StringVar(value=ALL)
        self.pmin_var, self.pmax_var = tk.StringVar(), tk.StringVar()
        self.stock_var = tk.IntVar(value=0)
        self.count_var = tk.StringVar()
        for var in (self.search_var, self.cat_var, self.size_var,
                    self.pmin_var, self.pmax_var, self.stock_var):
            var.trace_add("write", self._on_filter)

        self.apply_theme(DEFAULT_COLOR, "light")
        self.show_login()

    # ---------- оформление ----------
    def apply_theme(self, accent, mode):
        self.accent, self.mode = accent, mode
        self.pal = p = palette(mode, accent)
        ctk.set_appearance_mode(mode)
        self.configure(fg_color=p["bg"])
        s = ttk.Style(self)
        s.theme_use("clam")
        s.layout("Shop.Treeview", [("Treeview.treearea", {"sticky": "nswe"})])
        s.configure("Shop.Treeview", background=p["card"], fieldbackground=p["card"],
                    foreground=p["text"], rowheight=38, borderwidth=0, font=(FONT, 11))
        s.map("Shop.Treeview", background=[("selected", p["accent"])],
              foreground=[("selected", p["accent_fg"])])
        s.configure("Shop.Treeview.Heading", background=p["header"], foreground=p["muted"],
                    relief="flat", borderwidth=0, font=(FONT, 10, "bold"), padding=(8, 10))
        s.map("Shop.Treeview.Heading", background=[("active", p["header"])])

    def _font(self, size, bold=False):
        return ctk.CTkFont(family=FONT, size=size, weight="bold" if bold else "normal")

    def _btn(self, parent, text, command, kind="primary", **kw):
        p = self.pal
        if kind == "primary":
            colors = dict(fg_color=p["accent"], hover_color=p["accent_hover"], text_color=p["accent_fg"])
        elif kind == "danger":
            colors = dict(fg_color="#e5484d", hover_color="#c93b40", text_color="#ffffff")
        else:
            colors = dict(fg_color="transparent", hover_color=p["soft"], text_color=p["text"],
                          border_width=1, border_color=p["border"])
        return ctk.CTkButton(parent, text=text, command=command, height=38, corner_radius=10,
                             font=self._font(13, True), **colors, **kw)

    def _entry(self, parent, var=None, placeholder="", **kw):
        p = self.pal
        extra = {"textvariable": var} if var is not None else {"placeholder_text": placeholder}
        return ctk.CTkEntry(parent, height=38, corner_radius=8, fg_color=p["field"],
                            border_color=p["border"], text_color=p["text"],
                            placeholder_text_color=p["muted"], font=self._font(13), **extra, **kw)

    def _menu(self, parent, var, values):
        p = self.pal
        return ctk.CTkOptionMenu(parent, variable=var, values=values, height=38, corner_radius=8,
                                 fg_color=p["field"], button_color=p["field"],
                                 button_hover_color=p["soft"], text_color=p["text"],
                                 dropdown_fg_color=p["card"], dropdown_text_color=p["text"],
                                 dropdown_hover_color=p["soft"], font=self._font(13),
                                 dropdown_font=self._font(13), anchor="w", dynamic_resizing=False)

    def _new_screen(self, name):
        if self._job:
            self.after_cancel(self._job)
            self._job = None
        self.screen, self.tree = name, None
        if self.container is not None:
            self.container.destroy()
        self.container = ctk.CTkFrame(self, fg_color="transparent", corner_radius=0)
        self.container.pack(fill="both", expand=True)
        return self.container

    def _restyle(self, accent, mode):
        """Применить тему и перестроить каталог (вызывать через after)."""
        self.apply_theme(accent, mode)
        self.show_shop()

    def report_callback_exception(self, exc, val, tb):
        traceback.print_exception(exc, val, tb)
        messagebox.showerror("Ошибка", str(val))

    # ---------- вход ----------
    def show_login(self):
        self.user = None
        self.apply_theme(DEFAULT_COLOR, "light")
        box = self._new_screen("login")
        for var, value in ((self.search_var, ""), (self.cat_var, ALL), (self.size_var, ALL),
                           (self.pmin_var, ""), (self.pmax_var, "")):
            var.set(value)
        self.stock_var.set(0)
        p = self.pal

        box.grid_rowconfigure(0, weight=1)
        box.grid_columnconfigure(0, weight=5, uniform="cols")
        box.grid_columnconfigure(1, weight=6, uniform="cols")

        left = ctk.CTkFrame(box, fg_color=p["accent"], corner_radius=0)
        left.grid(row=0, column=0, sticky="nsew")
        ctk.CTkLabel(left, text="STYLE\nSTORE", font=self._font(48, True), justify="left",
                     text_color=p["accent_fg"]).place(relx=0.1, rely=0.34)
        ctk.CTkLabel(left, text="Одежда, в которой удобно жить", font=self._font(16),
                     text_color=p["accent_fg"]).place(relx=0.1, rely=0.60)

        right = ctk.CTkFrame(box, fg_color="transparent")
        right.grid(row=0, column=1, sticky="nsew")
        form = ctk.CTkFrame(right, fg_color=p["card"], corner_radius=18)
        form.place(relx=0.5, rely=0.5, anchor="center")
        ctk.CTkLabel(form, text="Добро пожаловать", font=self._font(24, True),
                     text_color=p["text"]).pack(anchor="w", padx=32, pady=(32, 2))
        ctk.CTkLabel(form, text="Войдите, чтобы открыть каталог", font=self._font(13),
                     text_color=p["muted"]).pack(anchor="w", padx=32)
        self.user_entry = self._entry(form, placeholder="Логин", width=320)
        self.user_entry.pack(padx=32, pady=(22, 10))
        self.pass_entry = self._entry(form, placeholder="Пароль", width=320, show="•")
        self.pass_entry.pack(padx=32)
        self._btn(form, "Войти", self.do_login, width=320).pack(padx=32, pady=(20, 8))
        self._btn(form, "Создать аккаунт", self.do_register, "ghost", width=320).pack(padx=32)
        ctk.CTkLabel(form, text="Демо:  admin / admin123   ·   user / user123", font=self._font(12),
                     text_color=p["muted"]).pack(pady=(18, 28))
        self.user_entry.bind("<Return>", lambda e: self.pass_entry.focus())
        self.pass_entry.bind("<Return>", lambda e: self.do_login())

    def do_login(self):
        user = self.db.authenticate(self.user_entry.get(), self.pass_entry.get())
        if not user:
            messagebox.showerror("Ошибка входа", "Неверный логин или пароль")
            return
        self.user = user
        mode = "dark" if user["dark_mode"] else "light"
        self.after(20, lambda: self._restyle(user["theme_color"], mode))

    def do_register(self):
        try:
            self.db.add_user(self.user_entry.get(), self.pass_entry.get(), "user")
        except ValueError as e:
            messagebox.showerror("Регистрация", str(e))
            return
        messagebox.showinfo("Регистрация", "Аккаунт создан. Теперь можно войти.")

    # ---------- каталог ----------
    def show_shop(self):
        p = self.pal
        is_admin = self.user["role"] == "admin"
        categories = [ALL] + self.db.categories()
        sizes = [ALL] + self.db.sizes()
        if self.cat_var.get() not in categories:
            self.cat_var.set(ALL)
        if self.size_var.get() not in sizes:
            self.size_var.set(ALL)

        box = self._new_screen("shop")
        box.grid_rowconfigure(0, weight=1)
        box.grid_columnconfigure(1, weight=1)

        # --- боковая панель ---
        side = ctk.CTkFrame(box, fg_color=p["card"], corner_radius=0, width=290)
        side.grid(row=0, column=0, sticky="ns")
        side.pack_propagate(False)

        bottom = ctk.CTkFrame(side, fg_color="transparent")
        bottom.pack(side="bottom", fill="x", padx=22, pady=20)
        self.dark_switch = ctk.CTkSwitch(bottom, text="Тёмная тема", command=self.toggle_dark,
                                         progress_color=p["accent"], text_color=p["text"],
                                         font=self._font(13))
        if self.mode == "dark":
            self.dark_switch.select()
        self.dark_switch.pack(anchor="w", pady=(0, 12))
        self._btn(bottom, f"🛒 Корзина ({sum(self.cart.values())})", self.show_cart).pack(fill="x", pady=(0, 8))
        self._btn(bottom, "Цвет оформления", self.choose_color, "ghost").pack(fill="x", pady=(0, 8))
        self._btn(bottom, "Выйти", lambda: self.after(20, self.show_login),
                  "ghost").pack(fill="x")

        ctk.CTkLabel(side, text="Style Store", font=self._font(22, True),
                     text_color=p["accent"]).pack(anchor="w", padx=22, pady=(24, 0))
        role = "администратор" if is_admin else "покупатель"
        ctk.CTkLabel(side, text=f"{self.user['username']} · {role}", font=self._font(12),
                     text_color=p["muted"]).pack(anchor="w", padx=22, pady=(2, 14))

        def caption(text):
            ctk.CTkLabel(side, text=text, font=self._font(12),
                         text_color=p["muted"]).pack(anchor="w", padx=22, pady=(10, 4))

        caption("Поиск")
        self._entry(side, self.search_var).pack(fill="x", padx=22)
        caption("Категория")
        self._menu(side, self.cat_var, categories).pack(fill="x", padx=22)
        caption("Размер")
        self._menu(side, self.size_var, sizes).pack(fill="x", padx=22)
        caption("Цена, ₽  (от — до)")
        prices = ctk.CTkFrame(side, fg_color="transparent")
        prices.pack(fill="x", padx=22)
        prices.grid_columnconfigure((0, 1), weight=1, uniform="price")
        self._entry(prices, self.pmin_var).grid(row=0, column=0, sticky="ew", padx=(0, 4))
        self._entry(prices, self.pmax_var).grid(row=0, column=1, sticky="ew", padx=(4, 0))
        ctk.CTkSwitch(side, text="Только в наличии", variable=self.stock_var,
                      progress_color=p["accent"], text_color=p["text"],
                      font=self._font(13)).pack(anchor="w", padx=22, pady=(16, 8))
        self._btn(side, "Сбросить фильтры", self.reset_filters, "ghost").pack(fill="x", padx=22, pady=(4, 0))

        # --- основная область ---
        main = ctk.CTkFrame(box, fg_color="transparent")
        main.grid(row=0, column=1, sticky="nsew", padx=28, pady=24)
        main.grid_columnconfigure(0, weight=1)
        main.grid_rowconfigure(1, weight=1)

        head = ctk.CTkFrame(main, fg_color="transparent")
        head.grid(row=0, column=0, sticky="ew", pady=(0, 16))
        head.grid_columnconfigure(0, weight=1)
        titles = ctk.CTkFrame(head, fg_color="transparent")
        titles.grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(titles, text="Каталог", font=self._font(28, True),
                     text_color=p["text"]).pack(anchor="w")
        ctk.CTkLabel(titles, textvariable=self.count_var, font=self._font(13),
                     text_color=p["muted"]).pack(anchor="w")
        if is_admin:
            actions = ctk.CTkFrame(head, fg_color="transparent")
            actions.grid(row=0, column=1, sticky="e")
            self._btn(actions, "+ Добавить товар", self.add_dialog, width=160).pack(side="left", padx=(0, 8))
            self._btn(actions, "Удалить выбранные", self.delete_selected, "danger", width=170).pack(side="left")

        self.products_frame = ctk.CTkScrollableFrame(main, fg_color="transparent", corner_radius=12)
        self.products_frame.grid(row=1, column=0, sticky="nsew")
        for col in range(3):
            self.products_frame.grid_columnconfigure(col, weight=1, uniform="products")
        self.refresh()

    def _on_filter(self, *_):
        if self.screen != "shop" or not hasattr(self, "products_frame"):
            return
        if self._job:
            self.after_cancel(self._job)
        self._job = self.after(200, self.refresh)

    def reset_filters(self):
        self.search_var.set("")
        self.cat_var.set(ALL)
        self.size_var.set(ALL)
        self.pmin_var.set("")
        self.pmax_var.set("")
        self.stock_var.set(0)

    def refresh(self):
        self._job = None
        if self.screen != "shop" or not hasattr(self, "products_frame"):
            return
        def num(var):
            value = var.get().strip().replace(",", ".")
            return float(value) if value else None
        try:
            pmin, pmax = num(self.pmin_var), num(self.pmax_var)
        except ValueError:
            self.count_var.set("Цена в фильтре должна быть числом")
            return
        cat, size = self.cat_var.get(), self.size_var.get()
        rows = self.db.list_products(search=self.search_var.get(),
            category=None if cat == ALL else cat, size=None if size == ALL else size,
            price_min=pmin, price_max=pmax, in_stock=bool(self.stock_var.get()))
        self.rows = {r["id"]: r for r in rows}
        for child in self.products_frame.winfo_children():
            child.destroy()
        self._images = []
        p = self.pal
        for index, item in enumerate(rows):
            card = ctk.CTkFrame(self.products_frame, fg_color=p["card"],
                                corner_radius=14, border_width=1, border_color=p["border"])
            card.grid(row=index // 3, column=index % 3, sticky="nsew", padx=8, pady=8)
            photo_box = ctk.CTkFrame(card, fg_color=p["field"], corner_radius=10, height=175)
            photo_box.pack(fill="x", padx=10, pady=(10, 7))
            photo_box.pack_propagate(False)
            image_path = item.get("image_path") or ""
            if image_path and os.path.isfile(image_path):
                try:
                    img = Image.open(image_path)
                    img.thumbnail((260, 165))
                    photo = ctk.CTkImage(light_image=img, dark_image=img, size=img.size)
                    self._images.append(photo)
                    ctk.CTkLabel(photo_box, text="", image=photo).pack(expand=True)
                except Exception:
                    ctk.CTkLabel(photo_box, text="Фото не удалось открыть",
                                 text_color=p["muted"]).pack(expand=True)
            else:
                ctk.CTkLabel(photo_box, text="Нет фотографии", font=self._font(13),
                             text_color=p["muted"]).pack(expand=True)
            ctk.CTkLabel(card, text=item["name"], font=self._font(15, True),
                         text_color=p["text"], wraplength=230, justify="left"
                         ).pack(anchor="w", padx=14, pady=(4, 2))
            meta = f'{item["brand"] or "Без бренда"} · {item["category"]} · {item["size"]}'
            ctk.CTkLabel(card, text=meta, font=self._font(11),
                         text_color=p["muted"], wraplength=230).pack(anchor="w", padx=14)
            ctk.CTkLabel(card, text=money(item["price"]), font=self._font(19, True),
                         text_color=p["accent"]).pack(anchor="w", padx=14, pady=(8, 2))
            stock_text = f'В наличии: {item["stock"]}' if item["stock"] else "Нет в наличии"
            ctk.CTkLabel(card, text=stock_text, font=self._font(11),
                         text_color=p["muted"]).pack(anchor="w", padx=14)
            actions = ctk.CTkFrame(card, fg_color="transparent")
            actions.pack(fill="x", padx=10, pady=10)
            ctk.CTkButton(actions, text="Подробнее", width=92, height=34,
                fg_color="transparent", border_width=1, border_color=p["border"],
                text_color=p["text"], hover_color=p["soft"],
                command=lambda x=item: self.show_product_details(x)).pack(side="left", padx=(0, 5))
            ctk.CTkButton(actions, text="В корзину", height=34, fg_color=p["accent"],
                hover_color=p["accent_hover"], text_color=p["accent_fg"],
                state="normal" if item["stock"] > 0 else "disabled",
                command=lambda pid=item["id"]: self.add_to_cart(pid)
                ).pack(side="left", fill="x", expand=True)
        self.count_var.set(f"Найдено товаров: {len(rows)}")

    def add_to_cart(self, product_id):
        item = self.rows.get(product_id)
        if not item:
            return
        current = self.cart.get(product_id, 0)
        if current >= item["stock"]:
            messagebox.showinfo("Корзина", "Больше товара нет на складе")
            return
        self.cart[product_id] = current + 1
        self.show_shop()

    def show_cart(self):
        p = self.pal
        dlg = self._dialog("Корзина", 650, 560)
        ctk.CTkLabel(dlg, text="Ваша корзина", font=self._font(23, True),
                     text_color=p["text"]).pack(anchor="w", padx=22, pady=(18, 8))
        body = ctk.CTkScrollableFrame(dlg, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=14)
        total = 0
        for pid, qty in list(self.cart.items()):
            item = next((x for x in self.db.list_products() if x["id"] == pid), None)
            if not item:
                continue
            line = ctk.CTkFrame(body, fg_color=p["card"], corner_radius=10)
            line.pack(fill="x", pady=5, padx=3)
            ctk.CTkLabel(line, text=item["name"], font=self._font(13, True),
                         text_color=p["text"]).pack(side="left", padx=12, pady=12)
            ctk.CTkLabel(line, text=money(item["price"] * qty),
                         text_color=p["accent"], font=self._font(13, True)).pack(side="right", padx=10)
            controls = ctk.CTkFrame(line, fg_color="transparent")
            controls.pack(side="right", padx=6)
            ctk.CTkButton(controls, text="−", width=28, height=28,
                command=lambda x=pid: self._cart_change(dlg, x, -1)).pack(side="left", padx=2)
            ctk.CTkLabel(controls, text=str(qty), text_color=p["text"]).pack(side="left", padx=5)
            ctk.CTkButton(controls, text="+", width=28, height=28,
                command=lambda x=pid: self._cart_change(dlg, x, 1)).pack(side="left", padx=2)
            ctk.CTkButton(controls, text="×", width=28, height=28, fg_color="#c43d45",
                command=lambda x=pid: self._cart_remove(dlg, x)).pack(side="left", padx=2)
            total += item["price"] * qty
        if not self.cart:
            ctk.CTkLabel(body, text="Корзина пока пуста", text_color=p["muted"],
                         font=self._font(15)).pack(pady=40)
        ctk.CTkLabel(dlg, text=f"Итого: {money(total)}", font=self._font(20, True),
                     text_color=p["accent"]).pack(anchor="e", padx=24, pady=12)
        buttons = ctk.CTkFrame(dlg, fg_color="transparent")
        buttons.pack(fill="x", padx=20, pady=(0, 18))
        self._btn(buttons, "Очистить", lambda: self._cart_clear(dlg), "ghost").pack(side="left")
        self._btn(buttons, "Оформить заказ", lambda: self.checkout(dlg),
                  width=190).pack(side="right")
        self._btn(buttons, "Закрыть", dlg.destroy, "ghost").pack(side="right", padx=8)

    def _cart_change(self, dlg, pid, delta):
        qty = self.cart.get(pid, 0) + delta
        item = next((x for x in self.db.list_products() if x["id"] == pid), None)
        if qty <= 0:
            self.cart.pop(pid, None)
        elif item and qty <= item["stock"]:
            self.cart[pid] = qty
        else:
            messagebox.showinfo("Корзина", "Недостаточно товара на складе", parent=dlg)
        dlg.destroy()
        self.show_cart()

    def _cart_remove(self, dlg, pid):
        self.cart.pop(pid, None)
        dlg.destroy()
        self.show_cart()

    def _cart_clear(self, dlg):
        self.cart.clear()
        dlg.destroy()
        self.show_cart()

    def checkout(self, dlg):
        if not self.cart:
            messagebox.showinfo("Корзина", "Добавьте товары перед оформлением", parent=dlg)
            return
        if not messagebox.askyesno("Подтверждение",
            "Оформить заказ и списать товары со склада?", parent=dlg):
            return
        for pid, qty in self.cart.items():
            if not self.db.change_stock(pid, -qty):
                messagebox.showerror("Ошибка", "Остаток изменился. Обновите корзину.", parent=dlg)
                return
        self.cart.clear()
        dlg.destroy()
        messagebox.showinfo("Заказ", "Заказ оформлен! Спасибо за покупку.")
        self.show_shop()

    def show_product_details(self, item):
        p = self.pal
        dlg = self._dialog("Информация о товаре", 440, 440)
        ctk.CTkLabel(dlg, text=item["name"], font=self._font(22, True),
                     text_color=p["text"], wraplength=380).pack(anchor="w", padx=22, pady=(22, 8))
        ctk.CTkLabel(dlg, text=f'{item["category"]} · {item["size"]} · {item["color"] or "—"}',
                     text_color=p["muted"]).pack(anchor="w", padx=22)
        ctk.CTkLabel(dlg, text=money(item["price"]), font=self._font(25, True),
                     text_color=p["accent"]).pack(anchor="w", padx=22, pady=12)
        ctk.CTkLabel(dlg, text=item.get("description") or "Описание не указано",
                     wraplength=380, justify="left", text_color=p["text"]
                     ).pack(anchor="w", padx=22, pady=8)
        self._btn(dlg, "Закрыть", dlg.destroy, "ghost").pack(side="bottom", fill="x", padx=22, pady=18)

    # ---------- диалоги ----------
    def _dialog(self, title, width, height):
        dlg = ctk.CTkToplevel(self)
        dlg.title(title)
        dlg.geometry(f"{width}x{height}")
        dlg.resizable(False, False)
        dlg.configure(fg_color=self.pal["bg"])
        dlg.transient(self)
        dlg.after(200, lambda: self._grab(dlg))
        return dlg

    @staticmethod
    def _grab(dlg):
        try:
            dlg.lift()
            dlg.focus_force()
            dlg.grab_set()
        except tk.TclError:
            pass

    def show_details(self, _event=None):
        selected = self.tree.selection()
        item = self.rows.get(int(selected[0])) if len(selected) == 1 else None
        if not item:
            return
        p = self.pal
        dlg = self._dialog("Товар", 420, 430)
        ctk.CTkLabel(dlg, text=item["name"], font=self._font(22, True), text_color=p["text"],
                     wraplength=370, justify="left").pack(anchor="w", padx=24, pady=(24, 2))
        ctk.CTkLabel(dlg, text=f"{item['brand'] or 'Без бренда'} · {item['category']}",
                     font=self._font(13), text_color=p["muted"]).pack(anchor="w", padx=24)
        ctk.CTkLabel(dlg, text=money(item["price"]), font=self._font(28, True),
                     text_color=p["accent"]).pack(anchor="w", padx=24, pady=(14, 10))
        info = (f"Размер: {item['size']}     Цвет: {item['color'] or '—'}     "
                f"На складе: {item['stock']}")
        ctk.CTkLabel(dlg, text=info, font=self._font(13), text_color=p["text"]).pack(anchor="w", padx=24)
        ctk.CTkLabel(dlg, text=item["description"] or "Описание не указано.", font=self._font(13),
                     text_color=p["muted"], wraplength=372, justify="left").pack(anchor="w", padx=24, pady=16)
        self._btn(dlg, "Закрыть", dlg.destroy, "ghost").pack(side="bottom", fill="x", padx=24, pady=20)

    def add_dialog(self):
        p = self.pal
        dlg = self._dialog("Новый товар", 480, 700)
        ctk.CTkLabel(dlg, text="Новый товар", font=self._font(22, True),
                     text_color=p["text"]).pack(anchor="w", padx=24, pady=(22, 4))
        form = ctk.CTkFrame(dlg, fg_color="transparent")
        form.pack(fill="x", padx=20)
        form.grid_columnconfigure((0, 1), weight=1, uniform="f")

        v = {"name": tk.StringVar(), "category": tk.StringVar(), "brand": tk.StringVar(),
             "size": tk.StringVar(value="M"), "color": tk.StringVar(),
             "price": tk.StringVar(), "stock": tk.StringVar(value="1")}

        def put(row, col, label, widget, span=1):
            ctk.CTkLabel(form, text=label, font=self._font(12), text_color=p["muted"]).grid(
                row=row * 2, column=col, columnspan=span, sticky="w", padx=4, pady=(10, 2))
            widget.grid(row=row * 2 + 1, column=col, columnspan=span, sticky="ew", padx=4)

        put(0, 0, "Название", self._entry(form, v["name"]), 2)
        category_box = ctk.CTkComboBox(
            form, variable=v["category"], values=self.db.categories(), height=38, corner_radius=8,
            fg_color=p["field"], border_color=p["border"], button_color=p["field"],
            button_hover_color=p["soft"], text_color=p["text"], dropdown_fg_color=p["card"],
            dropdown_text_color=p["text"], dropdown_hover_color=p["soft"], font=self._font(13))
        put(1, 0, "Категория (можно новую)", category_box)
        put(1, 1, "Бренд", self._entry(form, v["brand"]))
        put(2, 0, "Размер", self._menu(form, v["size"], SIZE_ORDER))
        put(2, 1, "Цвет", self._entry(form, v["color"]))
        put(3, 0, "Цена, ₽", self._entry(form, v["price"]))
        put(3, 1, "Количество", self._entry(form, v["stock"]))
        image_source = {"path": ""}
        image_label = ctk.CTkLabel(form, text="Фото не выбрано", text_color=p["muted"])
        def choose_image():
            path = filedialog.askopenfilename(parent=dlg, title="Выберите фото товара",
                filetypes=[("Изображения", "*.png *.jpg *.jpeg *.webp *.bmp")])
            if path:
                image_source["path"] = path
                image_label.configure(text=Path(path).name)
        put(4, 0, "Фотография товара", ctk.CTkButton(form, text="Выбрать фото…",
            command=choose_image, height=36), 2)
        image_label.grid(row=10, column=0, columnspan=2, sticky="w", padx=8, pady=(3, 0))
        description = ctk.CTkTextbox(form, height=75, corner_radius=8, fg_color=p["field"],
                                     text_color=p["text"], border_width=1, border_color=p["border"],
                                     font=self._font(13))
        put(6, 0, "Описание", description, 2)

        def save():
            try:
                price = float(v["price"].get().replace(",", "."))
                stock = int(v["stock"].get())
            except ValueError:
                messagebox.showerror("Ошибка", "Цена и количество должны быть числами", parent=dlg)
                return
            try:
                saved_image = ""
                if image_source["path"]:
                    folder = Path(__file__).resolve().parent.parent / "product_images"
                    folder.mkdir(exist_ok=True)
                    source = Path(image_source["path"])
                    saved = folder / f"product_{int(__import__('time').time() * 1000)}{source.suffix.lower()}"
                    shutil.copy2(source, saved)
                    saved_image = str(saved)
                self.db.add_product(v["name"].get(), v["category"].get(), v["brand"].get(),
                                    v["size"].get(), v["color"].get(), price, stock,
                                    description.get("1.0", "end"), saved_image)
            except ValueError as e:
                messagebox.showerror("Ошибка", str(e), parent=dlg)
                return
            dlg.destroy()
            self.after(30, self.show_shop)

        buttons = ctk.CTkFrame(dlg, fg_color="transparent")
        buttons.pack(side="bottom", fill="x", padx=24, pady=20)
        buttons.grid_columnconfigure((0, 1), weight=1, uniform="b")
        self._btn(buttons, "Отмена", dlg.destroy, "ghost").grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self._btn(buttons, "Сохранить", save).grid(row=0, column=1, sticky="ew", padx=(6, 0))

    def delete_selected(self):
        ids = [int(i) for i in self.tree.selection()]
        if not ids:
            messagebox.showinfo("Удаление", "Выберите товары в таблице")
            return
        if not messagebox.askyesno("Удаление", f"Удалить выбранные товары ({len(ids)})?"):
            return
        for pid in ids:
            self.db.delete_product(pid)
        self.after(30, self.show_shop)

    # ---------- цвет и тёмная тема ----------
    def choose_color(self):
        p = self.pal
        dlg = self._dialog("Цвет оформления", 380, 270)
        ctk.CTkLabel(dlg, text="Акцентный цвет", font=self._font(20, True),
                     text_color=p["text"]).pack(pady=(22, 10))
        grid = ctk.CTkFrame(dlg, fg_color="transparent")
        grid.pack()

        def pick(color):
            dlg.destroy()
            self._set_accent(color)

        for i, color in enumerate(PRESET_COLORS):
            ctk.CTkButton(grid, text="", width=40, height=40, corner_radius=20, fg_color=color,
                          hover_color=darken(color), command=lambda c=color: pick(c)
                          ).grid(row=i // 5, column=i % 5, padx=6, pady=6)

        def custom():
            _, chosen = colorchooser.askcolor(color=self.accent, parent=dlg, title="Свой цвет")
            if chosen:
                pick(chosen)

        self._btn(dlg, "Свой цвет…", custom, "ghost").pack(pady=14, padx=24, fill="x")

    def _set_accent(self, color):
        self.db.save_theme(self.user["id"], color, self.mode == "dark")
        self.user["theme_color"] = color.lower()
        self.after(60, lambda: self._restyle(color.lower(), self.mode))

    def toggle_dark(self):
        mode = "dark" if self.dark_switch.get() else "light"
        self.db.save_theme(self.user["id"], self.accent, mode == "dark")
        self.user["dark_mode"] = mode == "dark"
        self.after(60, lambda: self._restyle(self.accent, mode))